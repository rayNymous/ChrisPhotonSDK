﻿namespace RecastNavCSharp.Crowd
{
    public class CrowdNeighbor
    {
        public int Idx;
        public float Dist;
    }
}