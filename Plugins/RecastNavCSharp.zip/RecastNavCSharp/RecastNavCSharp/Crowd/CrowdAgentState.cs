﻿namespace RecastNavCSharp.Crowd
{
    public enum CrowdAgentState
    {
        Invalid,
        Walking,
        OffMesh
    }
}