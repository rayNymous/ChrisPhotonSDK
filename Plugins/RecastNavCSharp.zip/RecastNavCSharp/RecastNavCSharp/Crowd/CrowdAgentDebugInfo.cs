﻿namespace RecastNavCSharp.Crowd
{
    public class CrowdAgentDebugInfo
    {
        public int Idx;
        public float[] OptStart = new float[3];
        public float[] OptEnd = new float[3];
        public ObstacleAvoidanceDebugData Vod;
    }
}