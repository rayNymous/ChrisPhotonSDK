﻿namespace RecastNavCSharp.Crowd
{
    public class ObstacleCircle
    {
        public float[] p = new float[3];
        public float[] vel = new float[3];
        public float[] dvel = new float[3];
        public float rad;
        public float[] dp = new float[3];
        public float[] np = new float[3];
    }
}