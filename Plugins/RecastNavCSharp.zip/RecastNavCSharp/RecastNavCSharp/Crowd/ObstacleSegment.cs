﻿namespace RecastNavCSharp.Crowd
{
    public class ObstacleSegment
    {
        public float[] p = new float[3];
        public float[] q = new float[3];
        public bool touch;
    }
}