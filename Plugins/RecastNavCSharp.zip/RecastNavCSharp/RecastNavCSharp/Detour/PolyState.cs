﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Detour
{
    [Serializable]
	public class PolyState
	{
        public int Flags { get; set; }
        public short Area { get; set; }
	}
}
