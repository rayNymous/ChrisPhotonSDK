﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Xml.Serialization;
using Detour;
using NUnit.Framework;
using Recast;
using Recast.Data;
using RecastNavCSharp.Recast.Data;

namespace RecastNavCSharpTests
{
    
    public class RecastTests
    {
        private Config _config;

        public float CellSize { get; set; }
        public float CellHeight { get; set; }
        public float AgentHeight { get; set; }
        public float AgentRadius { get; set; }
        public float AgentMaxClimb { get; set; }
        public float EdgeMaxError { get; set; }
        public float BuildTime { get; set; }
        public int AgentMaxSlope { get; set; }
        public int RegionMinSize { get; set; }
        public int RegionMergeSize { get; set; }
        public int EdgeMaxLen { get; set; }
        public int VertsPerPoly { get; set; }
        public int DetailSampleDist { get; set; }
        public int DetailSampleMaxError { get; set; }

        Geometry _geom = new Geometry("nav_test.obj");
        public int TileSize { get; set; }
        public int TileHeight { get; set; }
        public int TileWidth { get; set; }
        public int MaxTiles { get; set; }
        public int MaxPolysPerTile { get; set; }

        [TestFixtureSetUp]
        public void Init()
        {
            CellSize = 0.300000f;
            CellHeight = 0.2f;
            AgentHeight = 2.0f;
            AgentRadius = .6f;
            AgentMaxClimb = 0.9f;
            AgentMaxSlope = 45;
            RegionMinSize = 8;
            RegionMergeSize = 20;
//            MonotonePartitioning = false;
            EdgeMaxLen = 12;
            EdgeMaxError = 1.3f;
            VertsPerPoly = 6;
            DetailSampleDist = 6;
            DetailSampleMaxError = 1;
            TileSize = 128;
        }

        [Test]
        public NavMeshBuilder TestRecastNavMeshCreation()
        {
            _config = new Config()
            {
                CellSize = CellSize,
                CellHeight = CellHeight,
                WalkableSlopeAngle = AgentMaxSlope,
                WalkableHeight = (int)Math.Ceiling(AgentHeight / CellHeight),
                WalkableClimb = (int)Math.Floor(AgentMaxClimb / CellHeight),
                WalkableRadius = (int)Math.Ceiling(AgentRadius / CellSize),
                MaxEdgeLength = (int)(EdgeMaxLen / CellSize),
                MaxSimplificationError = EdgeMaxError,
                MinRegionArea = (int)(RegionMinSize * RegionMinSize),
                MergeRegionArea = (int)(RegionMergeSize * RegionMergeSize),
                MaxVertexesPerPoly = (int)VertsPerPoly,
                DetailSampleDistance = DetailSampleDist < 0.9 ? 0 : CellSize * DetailSampleDist,
                DetailSampleMaxError = CellHeight * DetailSampleMaxError,
            };


            Geometry geom = new Geometry("nav_test.obj");
            //BuildGeometry(_config, geom);
            _config.CalculateGridSize(geom);
            geom.CreateChunkyTriMesh();
            _geom.AddOffMeshConnection(new RecastVertex(21.6141f, -2.3695f, 1.8229f), new RecastVertex(30.4232f, -1.9952f, 1.9149f), 0.6f, true, 5, 8);
            _geom.AddOffMeshConnection(new RecastVertex(20.3849f, -2.3700f, -16.6421f), new RecastVertex(32.7288f, -0.2395f, -16.2231f), 0.6f, true, 5, 8);
            _geom.AddOffMeshConnection(new RecastVertex(41.2371f, -2.4367f, -16.7210f), new RecastVertex(43.4751f, -0.2510f, -3.8171f), 0.6f, true, 5, 8);

            HeightField heightfield = new HeightField(_config.Width, _config.Height, _config.MinBounds.ToArray(), _config.MaxBounds.ToArray(), _config.CellSize, _config.CellHeight);
            short[] triAreas = new short[geom.NumTriangles];
            geom.MarkWalkableTriangles(_config.WalkableSlopeAngle, ref triAreas);

            heightfield.RasterizeTriangles(geom, triAreas, _config.WalkableClimb);

            heightfield.FilterLowHangingWalkableObstacles(_config.WalkableClimb);
            heightfield.FilterLedgeSpans(_config.WalkableHeight, _config.WalkableClimb);
            heightfield.FilterWalkableLowHeightSpans(_config.WalkableHeight);

            CompactHeightfield compactHeightfield = new CompactHeightfield(_config.WalkableHeight, _config.WalkableClimb, heightfield);
            compactHeightfield.ErodeWalkableArea(_config.WalkableRadius);
            compactHeightfield.BuildDistanceField();
            compactHeightfield.BuildRegions(0, _config.MinRegionArea, _config.MergeRegionArea);

            ContourSet contourSet = new ContourSet(compactHeightfield, _config.MaxSimplificationError, _config.MaxEdgeLength);

            PolyMesh polyMesh = new PolyMesh(contourSet, _config.MaxVertexesPerPoly);

            DetailPolyMesh detailPolyMesh = new DetailPolyMesh(polyMesh, compactHeightfield, _config.DetailSampleDistance,
                                                                _config.DetailSampleMaxError);


            // Convert the Areas and Flags for path weighting
            for (int i = 0; i < polyMesh.NPolys; i++)
            {

                if (polyMesh.Areas[i] == Geometry.WalkableArea)
                {
                    polyMesh.Areas[i] = 0; // Sample_polyarea_ground
                    polyMesh.Flags[i] = 1; // Samply_polyflags_walk
                }
            }
            NavMeshCreateParams param = new NavMeshCreateParams
            {
                Verts = polyMesh.Verts,
                VertCount = polyMesh.NVerts,
                Polys = polyMesh.Polys,
                PolyAreas = polyMesh.Areas,
                PolyFlags = polyMesh.Flags,
                PolyCount = polyMesh.NPolys,
                Nvp = polyMesh.Nvp,
                DetailMeshes = detailPolyMesh.Meshes,
                DetailVerts = detailPolyMesh.Verts,
                DetailVertsCount = detailPolyMesh.NVerts,
                DetailTris = detailPolyMesh.Tris,
                DetailTriCount = detailPolyMesh.NTris,

                // Off Mesh data
                OffMeshConVerts = _geom.OffMeshConnectionVerts.ToArray(),
                OffMeshConRad = _geom.OffMeshConnectionRadii.ToArray(),
                OffMeshConDir = _geom.OffMeshConnectionDirections.ToArray(),
                OffMeshConAreas = _geom.OffMeshConnectionAreas.ToArray(),
                OffMeshConFlags = _geom.OffMeshConnectionFlags.ToArray(),
                OffMeshConUserId = _geom.OffMeshConnectionIds.ToArray(),
                OffMeshConCount = (int)_geom.OffMeshConnectionCount,
                // end off mesh data

                WalkableHeight = AgentHeight,
                WalkableRadius = AgentRadius,
                WalkableClimb = AgentMaxClimb,
                BMin = new float[] { polyMesh.BMin[0], polyMesh.BMin[1], polyMesh.BMin[2] },
                BMax = new float[] { polyMesh.BMax[0], polyMesh.BMax[1], polyMesh.BMax[2] },
                Cs = polyMesh.Cs,
                Ch = polyMesh.Ch,
                BuildBvTree = true,
                TileX = 0,
                TileY = 0,
                TileLayer = 0
            };
            var builder = new Detour.NavMeshBuilder(param);
            NavMesh navMesh = new NavMesh();
            navMesh.Init(builder, 1);

            NavMeshQuery navMeshQuery;
            QueryFilter filter;
            InitializeQuery(navMesh, out navMeshQuery, out filter);

            float[] startPos = new [] { 45.5873f, -2.3565f, -24.6714f };
            float[] endPos = new [] { 21.3897f, -2.3689f, 8.4490f };
            long startRef = 0, endRef = 0;
            float[] nearestPt = new float[3];
            int MaxPolys = 256;
            long[] polys = new long[MaxPolys];
            int polyCount = 0;
            bool doneSmoothing;

            Status status = navMeshQuery.FindNearestPoly(startPos, new[] { 2f, 4f, 2f }, filter, ref startRef, ref nearestPt);
            status = navMeshQuery.FindNearestPoly(endPos, new[] { 2f, 4f, 2f }, filter, ref endRef, ref nearestPt);
            status = navMeshQuery.FindPath(startRef, endRef, startPos, endPos, filter, ref polys, ref polyCount, MaxPolys);

            long[] smoothPolys = new long[MaxPolys];
            Array.Copy(polys, smoothPolys, polyCount);
            int smoothPolyCount = polyCount;
            float[] SmoothPath = new float[2048 * 3];

            float[] iterPos = new float[3], targetPos = new float[3];

            navMeshQuery.ClosestPointOnPoly(startRef, startPos, ref iterPos);
            navMeshQuery.ClosestPointOnPoly(smoothPolys[smoothPolyCount - 1], endPos, ref targetPos);

            float StepSize = 0.5f;
            float Slop = 0.01f;

            int SmoothPathNum = 0;
            Array.Copy(iterPos, 0, SmoothPath, SmoothPathNum * 3, 3);
            SmoothPathNum++;

            while (smoothPolyCount > 0 && SmoothPathNum < 2048)
            {

                float[] steerPos = new float[3];
                short steerPosFlag = 0;
                long steerPosRef = 0;

                if (!GetSteerTarget(navMeshQuery, iterPos, targetPos, Slop, smoothPolys, smoothPolyCount, steerPos, ref steerPosFlag, ref steerPosRef))
                    break;

                bool endOfPath = (steerPosFlag & StraightPathEnd) != 0;
                bool offMeshConnection = (steerPosFlag & StraightPathOffMeshConnection) != 0;

                float[] delta = Helper.VSub(steerPos[0], steerPos[1], steerPos[2], iterPos[0], iterPos[1], iterPos[2]);
                float len = (float)Math.Sqrt(Helper.VDot(delta, delta));

                if ((endOfPath || offMeshConnection) && len < StepSize)
                    len = 1;
                else
                {
                    len = StepSize / len;
                }

                float[] moveTarget = new float[3];
                Helper.VMad(ref moveTarget, iterPos, delta, len);

                float[] result = new float[3];
                long[] visited = new long[16];
                int nVisited = 0;

                navMeshQuery.MoveAlongSurface(smoothPolys[0], iterPos, moveTarget, filter, ref result, ref visited, ref nVisited, 16);
                smoothPolyCount = FixupCorridor(ref smoothPolys, smoothPolyCount, MaxPolys, visited, nVisited);
                float h = 0;
                navMeshQuery.GetPolyHeight(smoothPolys[0], result, ref h);
                result[1] = h;
                Array.Copy(result, iterPos, 3);

                if (endOfPath && InRange(iterPos, steerPos, Slop, 1.0f))
                {
                    Array.Copy(targetPos, iterPos, 3);
                    if (SmoothPathNum < 2048)
                    {
                        Array.Copy(iterPos, 0, SmoothPath, SmoothPathNum * 3, 3);
                        SmoothPathNum++;
                    }
                    break;
                }
                else if (offMeshConnection && InRange(iterPos, steerPos, Slop, 1.0f))
                {
                    // TODO: offmesh connection, we can add later
                }

                if (SmoothPathNum < 2048)
                {
                    Array.Copy(iterPos, 0, SmoothPath, SmoothPathNum * 3, 3);
                    SmoothPathNum++;
                }
            }
            doneSmoothing = true;
            return builder;
        }


        /// <summary>
        /// Static value to check if a connection is offmesh or not.
        /// </summary>
        protected int StraightPathOffMeshConnection
        {
            get { return 4; }
        }

        /// <summary>
        /// Static to check if the straight path is at the end
        /// </summary>
        protected int StraightPathEnd
        {
            get { return 2; }
        }

        static void Main()
        {
            RecastTests tests = new RecastTests();
            tests.Init();
            tests.TestRecastNavMeshCreation();
        }

        [Test]
        public void TestTileCreation()
        {
            _config = new Config()
            {
                CellSize = CellSize,
                CellHeight = CellHeight,
                WalkableSlopeAngle = AgentMaxSlope,
                WalkableHeight = (int)Math.Ceiling(AgentHeight / CellHeight),
                WalkableClimb = (int)Math.Floor(AgentMaxClimb / CellHeight),
                WalkableRadius = (int)Math.Ceiling(AgentRadius / CellSize),
                MaxEdgeLength = (int)(EdgeMaxLen / CellSize),
                MaxSimplificationError = EdgeMaxError,
                MinRegionArea = (int)(RegionMinSize * RegionMinSize),
                MergeRegionArea = (int)(RegionMergeSize * RegionMergeSize),
                MaxVertexesPerPoly = (int)VertsPerPoly,
                DetailSampleDistance = DetailSampleDist < 0.9 ? 0 : CellSize * DetailSampleDist,
                DetailSampleMaxError = CellHeight * DetailSampleMaxError,
                BorderSize = (int)Math.Ceiling(AgentRadius / CellSize) + 3,
                TileSize = TileSize,
            };

            _config.Width = _config.TileSize + _config.BorderSize * 2;
            _config.Height = _config.TileSize + _config.BorderSize * 2;

            _geom = new Geometry("nav_test.obj");
            //BuildGeometry(_config, geom);
            _config.CalculateGridSize(_geom);
            _geom.CreateChunkyTriMesh();
            _geom.AddOffMeshConnection(new RecastVertex(21.6141f, -2.3695f, 1.8229f), new RecastVertex(30.4232f, -1.9952f, 1.9149f), 0.6f, true, 5, 8);
            _geom.AddOffMeshConnection(new RecastVertex(20.3849f, -2.3700f, -16.6421f), new RecastVertex(32.7288f, -0.2395f, -16.2231f), 0.6f, true, 5, 8);
            _geom.AddOffMeshConnection(new RecastVertex(41.2371f, -2.4367f, -16.7210f), new RecastVertex(43.4751f, -0.2510f, -3.8171f), 0.6f, true, 5, 8);

            BuildTileSizeData();

            RecastVertex bmin = _geom.MinBounds;
            RecastVertex bmax = _geom.MaxBounds;
            RecastVertex tileBMin = new RecastVertex();
            RecastVertex tileBMax = new RecastVertex();
            float tcs = TileSize * CellSize;

            for (int y = 0; y < TileHeight; y++)
            {
                for (int x = 0; x < TileWidth; x++)
                {
                    tileBMin.X = bmin.X + x * tcs;
                    tileBMin.Y = bmin.Y;
                    tileBMin.Z = bmin.Z + y * tcs;

                    tileBMax.X = bmin.X + (x + 1) * tcs;
                    tileBMax.Y = bmax.Y;
                    tileBMax.Z = bmin.Z + (y + 1) * tcs;

                    BuildTileMesh(x, y, tileBMin, tileBMax);

                    // remove/add new tile?
                }
            }

        }

        [Test]
        public void TestFileReconstitution()
        {
            FileStream f = null;
            f = File.OpenRead("NavMesh128.xml");
            XmlSerializer xmlSerializer = new XmlSerializer(typeof(NavMeshSerializer));

            NavMeshQuery navMeshQuery;
            QueryFilter filter;
            InitializeQuery(((NavMeshSerializer)xmlSerializer.Deserialize(f)).Reconstitute(), out navMeshQuery, out filter);

            float[] startPos = new[] {21.31355f, -2.269517f, 26.8297f};
            //float[] startPos = new[] { 45.5873f, -2.3565f, -24.6714f };
            float[] endPos = new[] { -42.48365f, -1.269517f, -25.33443f };
            //float[] endPos = new[] { 21.3897f, -2.3689f, 8.4490f };
            long startRef = 0, endRef = 0;
            float[] nearestPt = new float[3];
            int MaxPolys = 256;
            long[] polys = new long[MaxPolys];
            int polyCount = 0;
            bool doneSmoothing;

            Status status = navMeshQuery.FindNearestPoly(startPos, new[] { 2f, 4f, 2f }, filter, ref startRef, ref nearestPt);
            status = navMeshQuery.FindNearestPoly(endPos, new[] { 2f, 4f, 2f }, filter, ref endRef, ref nearestPt);
            status = navMeshQuery.FindPath(startRef, endRef, startPos, endPos, filter, ref polys, ref polyCount, MaxPolys);

            long[] smoothPolys = new long[MaxPolys];
            Array.Copy(polys, smoothPolys, polyCount);
            int smoothPolyCount = polyCount;
            float[] SmoothPath = new float[2048 * 3];

            float[] iterPos = new float[3], targetPos = new float[3];

            navMeshQuery.ClosestPointOnPoly(startRef, startPos, ref iterPos);
            navMeshQuery.ClosestPointOnPoly(smoothPolys[smoothPolyCount - 1], endPos, ref targetPos);

            float StepSize = 0.5f;
            float Slop = 0.01f;

            int SmoothPathNum = 0;
            Array.Copy(iterPos, 0, SmoothPath, SmoothPathNum * 3, 3);
            SmoothPathNum++;

            while (smoothPolyCount > 0 && SmoothPathNum < 2048)
            {

                float[] steerPos = new float[3];
                short steerPosFlag = 0;
                long steerPosRef = 0;

                if (!GetSteerTarget(navMeshQuery, iterPos, targetPos, Slop, smoothPolys, smoothPolyCount, steerPos, ref steerPosFlag, ref steerPosRef))
                    break;

                bool endOfPath = (steerPosFlag & StraightPathEnd) != 0;
                bool offMeshConnection = (steerPosFlag & StraightPathOffMeshConnection) != 0;

                float[] delta = Helper.VSub(steerPos[0], steerPos[1], steerPos[2], iterPos[0], iterPos[1], iterPos[2]);
                float len = (float)Math.Sqrt(Helper.VDot(delta, delta));

                if ((endOfPath || offMeshConnection) && len < StepSize)
                    len = 1;
                else
                {
                    len = StepSize / len;
                }

                float[] moveTarget = new float[3];
                Helper.VMad(ref moveTarget, iterPos, delta, len);

                float[] result = new float[3];
                long[] visited = new long[16];
                int nVisited = 0;

                navMeshQuery.MoveAlongSurface(smoothPolys[0], iterPos, moveTarget, filter, ref result, ref visited, ref nVisited, 16);
                smoothPolyCount = FixupCorridor(ref smoothPolys, smoothPolyCount, MaxPolys, visited, nVisited);
                float h = 0;
                navMeshQuery.GetPolyHeight(smoothPolys[0], result, ref h);
                result[1] = h;
                Array.Copy(result, iterPos, 3);

                if (endOfPath && InRange(iterPos, steerPos, Slop, 1.0f))
                {
                    Array.Copy(targetPos, iterPos, 3);
                    if (SmoothPathNum < 2048)
                    {
                        Array.Copy(iterPos, 0, SmoothPath, SmoothPathNum * 3, 3);
                        SmoothPathNum++;
                    }
                    break;
                }
                else if (offMeshConnection && InRange(iterPos, steerPos, Slop, 1.0f))
                {
                    // TODO: offmesh connection, we can add later
                }

                if (SmoothPathNum < 2048)
                {
                    Array.Copy(iterPos, 0, SmoothPath, SmoothPathNum * 3, 3);
                    SmoothPathNum++;
                }
            }
            doneSmoothing = true;
        }

        public void InitializeQuery(Detour.NavMesh navMesh, out NavMeshQuery navMeshQuery, out QueryFilter filter)
        {
            navMeshQuery = new NavMeshQuery();
            navMeshQuery.Init(navMesh, 2048);
            filter = new QueryFilter();

            // These values need to me modifiable in the editor later using RecastArea
            filter.IncludeFlags = 15;
            filter.ExcludeFlags = 0;
            filter.SetAreaCost(1, 1.0f);
            filter.SetAreaCost(2, 10.0f);
            filter.SetAreaCost(3, 1.0f);
            filter.SetAreaCost(4, 1.0f);
            filter.SetAreaCost(5, 2);
            filter.SetAreaCost(6, 1.5f);
        }

        [Serializable]
        public class NavMeshSerializer
        {
            public NavMeshParams Param { get; set; }
            public NavMeshBuilder[] NavMeshBuilders { get; set; }

            public NavMeshSerializer()
            {
            }

            public NavMeshSerializer(NavMesh navMesh)
                : this()
            {
                Decompose(navMesh);
            }

            public void Decompose(NavMesh navMesh)
            {
                Param = navMesh.Param;

                NavMeshBuilders = new NavMeshBuilder[navMesh._tiles.Length];
                for (int i = 0; i < navMesh._tiles.Length; i++)
                {
                    NavMeshBuilders[i] = navMesh._tiles[i].Data;
                }
            }

            public NavMesh Reconstitute()
            {
                NavMesh navMesh = new NavMesh();
                navMesh.Init(Param);

                long tempRef = 0;
                long temp = 0;

                for (int i = 0; i < NavMeshBuilders.Length; i++)
                {
                    if (NavMeshBuilders[i] != null)
                    {
                        navMesh.AddTile(NavMeshBuilders[i], NavMesh.TileFreeData, tempRef, ref temp);
                        //tempRef = temp;
                    }
                }
                return navMesh;
            }
        }

        private NavMeshBuilder BuildTileMesh(int tx, int ty, RecastVertex min, RecastVertex max)
        {
            _config.Width = _config.TileSize + _config.BorderSize * 2;
            _config.Height = _config.TileSize + _config.BorderSize * 2;

            _config.MinBounds = new RecastVertex(min);
            _config.MaxBounds = new RecastVertex(max);
            _config.MinBounds.X -= ((float)_config.BorderSize) * _config.CellSize;
            _config.MinBounds.Z -= ((float)_config.BorderSize) * _config.CellSize;

            _config.MaxBounds.X += ((float)_config.BorderSize) * _config.CellSize;
            _config.MaxBounds.Z += ((float)_config.BorderSize) * _config.CellSize;

            HeightField heightfield = new HeightField(_config.Width, _config.Height, _config.MinBounds.ToArray(),
                                                      _config.MaxBounds.ToArray(), _config.CellSize, _config.CellHeight);


            short[] triAreas = new short[_geom.ChunkyTriMesh.MaxTrisPerChunk];

            float[] tbmin = new float[2], tbmax = new float[2];
            tbmin[0] = _config.MinBounds.X;
            tbmin[1] = _config.MinBounds.Z;

            tbmax[0] = _config.MaxBounds.X;
            tbmax[1] = _config.MaxBounds.Z;

            int[] cid = new int[512];

            int ncid = _geom.ChunkyTriMesh.GetChunksOverlappingRect(tbmin, tbmax, ref cid, 512);

            if (ncid == 0)
                return null;

            for (int i = 0; i < ncid; i++)
            {
                ChunkyTriMeshNode node = _geom.ChunkyTriMesh.Nodes[cid[i]];
                int[] tris = new int[node.n*3];
                Array.Copy(_geom.ChunkyTriMesh.Tris, node.i*3, tris, 0, node.n*3);
                List<int> ctris = new List<int>(tris);
                int nctris = node.n;

                Array.Clear(triAreas, 0, triAreas.Length);
                _geom.MarkWalkableTriangles(_config.WalkableSlopeAngle, ctris, nctris, ref triAreas);

                heightfield.RasterizeTriangles(_geom, ctris, nctris, triAreas, _config.WalkableClimb);
            }

            heightfield.FilterLowHangingWalkableObstacles(_config.WalkableClimb);
            heightfield.FilterLedgeSpans(_config.WalkableHeight, _config.WalkableClimb);
            heightfield.FilterWalkableLowHeightSpans(_config.WalkableHeight);


            CompactHeightfield compactHeightfield = new CompactHeightfield(_config.WalkableHeight, _config.WalkableClimb,
                                                                           heightfield);
            compactHeightfield.ErodeWalkableArea(_config.WalkableRadius);
            compactHeightfield.BuildDistanceField();
            compactHeightfield.BuildRegions(_config.BorderSize, _config.MinRegionArea, _config.MergeRegionArea);

            ContourSet contourSet = new ContourSet(compactHeightfield, _config.MaxSimplificationError,
                                                   _config.MaxEdgeLength);

            if (contourSet.NConts == 0)
                return null;

            PolyMesh polyMesh = new PolyMesh(contourSet, _config.MaxVertexesPerPoly);

            DetailPolyMesh detailPolyMesh = new DetailPolyMesh(polyMesh, compactHeightfield,
                                                               _config.DetailSampleDistance,
                                                               _config.DetailSampleMaxError);

            // Convert the Areas and Flags for path weighting
            for (int i = 0; i < polyMesh.NPolys; i++)
            {

                if (polyMesh.Areas[i] == Geometry.WalkableArea)
                {
                    polyMesh.Areas[i] = 0; // Sample_polyarea_ground
                    polyMesh.Flags[i] = 1; // Samply_polyflags_walk
                }
            }
            NavMeshCreateParams param = new NavMeshCreateParams
            {
                Verts = polyMesh.Verts,
                VertCount = polyMesh.NVerts,
                Polys = polyMesh.Polys,
                PolyAreas = polyMesh.Areas,
                PolyFlags = polyMesh.Flags,
                PolyCount = polyMesh.NPolys,
                Nvp = polyMesh.Nvp,
                DetailMeshes = detailPolyMesh.Meshes,
                DetailVerts = detailPolyMesh.Verts,
                DetailVertsCount = detailPolyMesh.NVerts,
                DetailTris = detailPolyMesh.Tris,
                DetailTriCount = detailPolyMesh.NTris,

                // Off Mesh data
                OffMeshConVerts = _geom.OffMeshConnectionVerts.ToArray(),
                OffMeshConRad = _geom.OffMeshConnectionRadii.ToArray(),
                OffMeshConDir = _geom.OffMeshConnectionDirections.ToArray(),
                OffMeshConAreas = _geom.OffMeshConnectionAreas.ToArray(),
                OffMeshConFlags = _geom.OffMeshConnectionFlags.ToArray(),
                OffMeshConUserId = _geom.OffMeshConnectionIds.ToArray(),
                OffMeshConCount = (int)_geom.OffMeshConnectionCount,
                // end off mesh data

                WalkableHeight = AgentHeight,
                WalkableRadius = AgentRadius,
                WalkableClimb = AgentMaxClimb,
                BMin = new float[] { polyMesh.BMin[0], polyMesh.BMin[1], polyMesh.BMin[2] },
                BMax = new float[] { polyMesh.BMax[0], polyMesh.BMax[1], polyMesh.BMax[2] },
                Cs = polyMesh.Cs,
                Ch = polyMesh.Ch,
                BuildBvTree = true,
                TileX = tx,
                TileY = ty,
                TileLayer = 0
            };
            return new Detour.NavMeshBuilder(param);
        }

        public void BuildTileSizeData()
        {
            RecastVertex bmin = _geom.MinBounds;
            RecastVertex bmax = _geom.MaxBounds;

            int gw = 0, gh = 0;

            CalcGridSize(bmin, bmax, _config.CellSize, out gw, out gh);

            int ts = TileSize;
            int tw = (gw + ts - 1) / ts;
            int th = (gh + ts - 1) / ts;

            TileWidth = tw;
            TileHeight = th;

            int tileBits = Math.Min(ilog2(nextPow2(th * tw)), 14);
            if (tileBits > 14)
                tileBits = 14;

            int polyBits = 22 - tileBits;
            MaxTiles = 1 << tileBits;
            MaxPolysPerTile = 1 << polyBits;
        }

        private void CalcGridSize(RecastVertex bmin, RecastVertex bmax, float cellSize, out int w, out int h)
        {
            w = (int)((bmax.X - bmin.X) / cellSize + 0.5f);
            h = (int)((bmax.Z - bmin.Z) / cellSize + 0.5f);
        }

        private int nextPow2(int v)
        {
            v--;
            v |= v >> 1;
            v |= v >> 2;
            v |= v >> 4;
            v |= v >> 8;
            v |= v >> 16;
            v++;
            return v;
        }

        private int ilog2(int v)
        {
            int r;
            int shift;

            r = ((v > 0xffff) ? 1 : 0) << 4;
            v >>= r;
            shift = ((v > 0xff) ? 1 : 0) << 3;
            v >>= shift;
            r |= shift;
            shift = ((v > 0xf) ? 1 : 0) << 2;
            v >>= shift;
            r |= shift;
            shift = ((v > 0x3) ? 1 : 0) << 1;
            v >>= shift;
            r |= shift;
            r |= (v >> 1);
            return r;
        }


        private bool GetSteerTarget(NavMeshQuery navMeshQuery, float[] startPos, float[] endPos, float minTargetDistance, long[] path, int pathSize, float[] steerPos, ref short steerPosFlag, ref long steerPosRef, float[] outPoints = null, int outPointCount = 0)
        {
            int MaxSteerPoints = 3;
            float[] steerPath = new float[MaxSteerPoints * 3];
            short[] steerPathFlags = new short[MaxSteerPoints];
            long[] steerPathPolys = new long[MaxSteerPoints];

            int nSteerPath = 0;

            navMeshQuery.FindStraightPath(startPos, endPos, path, pathSize, ref steerPath, ref steerPathFlags,
                                          ref steerPathPolys, ref nSteerPath, MaxSteerPoints);

            if (nSteerPath == 0)
                return false;

            if (outPoints != null)
            {
                outPointCount = nSteerPath;
                for (int i = 0; i < nSteerPath; i++)
                {
                    Array.Copy(steerPath, i * 3, outPoints, i * 3, 3);
                }
            }

            int ns = 0;
            while (ns < nSteerPath)
            {
                if ((steerPathFlags[ns] & StraightPathOffMeshConnection) != 0 ||
                    !InRange(steerPath[ns * 3 + 0], steerPath[ns * 3 + 1], steerPath[ns * 3 + 2], startPos, minTargetDistance, 1000.0f))
                    break;
                ns++;
            }

            if (ns >= nSteerPath)
                return false;

            Array.Copy(steerPath, ns * 3, steerPos, 0, 3);
            steerPos[1] = startPos[1];
            steerPosFlag = steerPathFlags[ns];
            steerPosRef = steerPathPolys[ns];

            return true;
        }

        /// <summary>
        /// Helper class for using an array instead of splitting out v1
        /// </summary>
        /// <param name="v1">array of 3 points for vector 1</param>
        /// <param name="v2">array of 3 points for vector 2</param>
        /// <param name="r">radius around which to search</param>
        /// <param name="h">height above or below to check for</param>
        /// <returns></returns>
        private bool InRange(float[] v1, float[] v2, float r, float h)
        {
            return InRange(v1[0], v1[1], v1[2], v2, r, h);
        }

        /// <summary>
        /// Checking if V1 is in range of V2
        /// </summary>
        /// <param name="v1x">V1 x-component</param>
        /// <param name="v1y">V1 y-component</param>
        /// <param name="v1z">V1 z-component</param>
        /// <param name="v2">Vector to check with</param>
        /// <param name="r">radius around v1 to check</param>
        /// <param name="h">height above and below v1 to check</param>
        /// <returns></returns>
        private bool InRange(float v1x, float v1y, float v1z, float[] v2, float r, float h)
        {
            float dx = v2[0] - v1x;
            float dy = v2[1] - v1y;
            float dz = v2[2] - v1z;
            return (dx * dx + dz * dz) < r * r && Math.Abs(dy) < h;
        }

        private int FixupCorridor(ref long[] path, int npath, int maxPath, long[] visited, int nVisited)
        {
            int furthestPath = -1;
            int furthestVisited = -1;

            for (int i = npath - 1; i >= 0; --i)
            {
                bool found = false;
                for (int j = nVisited - 1; j >= 0; --j)
                {
                    if (path[i] == visited[j])
                    {
                        furthestPath = i;
                        furthestVisited = j;
                        found = true;
                    }
                }
                if (found)
                    break;
            }

            if (furthestPath == -1 || furthestVisited == -1)
                return npath;

            int req = nVisited - furthestVisited;
            int orig = Math.Min(furthestPath + 1, npath);
            int size = Math.Max(0, npath - orig);
            if (req + size > maxPath)
                size = maxPath - req;
            if (size > 0)
                Array.Copy(path, orig, path, req, size);

            for (int i = 0; i < req; i++)
            {
                path[i] = visited[(nVisited - 1) - i];
            }

            return req + size;
        }
    }
}
